# Iceberg Memory for Cortico

Iceberg Memory is a Bot API 7 extension for Cortico. It stores source text in SQLite, queues source-linked extraction with the deployment's active model, and exposes the resulting index and original evidence to the Persona. Each deployment has its own storage and Persona seed.

Use Node.js 24 and a Cortico host supporting Bot API 7. Install the package in the host's extensions directory, create a dedicated deployment, and set its `deployment.json` to:

```json
{"bot":"cortico-bot-iceberg-memory"}
```

Select a model provider in that deployment. The default World is `console`. The deployment's `iceberg.seed` config accepts a custom Persona prompt. `iceberg.maxPrefixChars` limits the memory index in the system prefix and defaults to 6000.

Console inputs are stored from the original operator body. Other delivered external events are recorded as World observations. Completed assistant text is recorded as an assistant report. The bot sends queued text to the active provider for extraction when idle. SQLite and attachments live under the deployment's Memory directory. Memory tools can read new sources immediately, and Cortico's normal system-prefix rebuild loads the latest index.

The Persona exposes `memory_timeline`, `memory_expand`, `memory_read_source`, `memory_search`, and `memory_search_sources`. The status response includes extraction queue counts. A blocked or failed extraction needs an explicit recovery action. The preview's UI shows the queue status. The bundled engine preserves original sources through extraction failures.

The benchmark used the same MemoryBase engine in an isolated evaluation adapter. The results apply to that setup and its model/provider configurations. This package adds the runtime Bot wiring and generic Persona wording. The local engine source has no declared public-use license at this revision.
